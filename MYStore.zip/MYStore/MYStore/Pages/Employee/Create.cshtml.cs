using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace MYStore.Pages.Clients
{
    public class CreateModel : PageModel
    {
        public ClintInfo clientinfo = new ClintInfo();
        public string ErrorMsg = "";
        public string SuccessMsg = "";
        public void OnGet()
        {
        }
        public void OnPost()
        {
            clientinfo.name = Request.Form["name"];
            clientinfo.email = Request.Form["email"];
            clientinfo.phone = Request.Form["phone"];
            clientinfo.address = Request.Form["address"];

            if(clientinfo.name.Length == 0 || clientinfo.email.Length ==0 ||
                clientinfo.phone.Length == 0 || clientinfo.address.Length ==0)
            {
                ErrorMsg = "All the fields are required";
                return;
            }
            try
            {
                string connectionstring = "Data Source=DESKTOP-SABU4KG\\ARVINMSSQLSERVER;Initial Catalog=Arvin;Integrated Security=True";
                using(SqlConnection con = new SqlConnection(connectionstring))
                {
                    con.Open();
                    string sql = "Insert into client (name, email, phone, address) values(@name, @email, @phone, @address)";
                    using(SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@name", clientinfo.name);
                        cmd.Parameters.AddWithValue("@email", clientinfo.email);
                        cmd.Parameters.AddWithValue("@phone", clientinfo.phone);
                        cmd.Parameters.AddWithValue("@address", clientinfo.address);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch(Exception ex)
            {
                ErrorMsg = ex.Message;
                return;
            }

            clientinfo.name = ""; clientinfo.email = ""; clientinfo.phone = ""; clientinfo.address = "";
            SuccessMsg = "New client added correctly";
            Response.Redirect("Index");
        }
    }
}
