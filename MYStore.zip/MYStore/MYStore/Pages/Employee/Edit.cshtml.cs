using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace MYStore.Pages.Clients
{
    public class EditModel : PageModel
    {
        public ClintInfo clintInfo = new ClintInfo();
        public string ErrorMsg = "";
        public string SuccessMsg = "";
        public void OnGet()
        {
            string id = Request.Query["id"];

            try
            {
                string connectionstring = "Data Source=DESKTOP-SABU4KG\\ARVINMSSQLSERVER;Initial Catalog=Arvin;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionstring))
                {
                    con.Open();
                    string sql = "select * from client where id =@id";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                clintInfo.id = "" + reader.GetInt32(0);
                                clintInfo.name = reader.GetString(1);
                                clintInfo.email = reader.GetString(2);
                                clintInfo.phone = reader.GetString(3);
                                clintInfo.address = reader.GetString(4);
                                clintInfo.createddt = reader.GetDateTime(5).ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.Message;
                return;
            }
        }

        public void OnPost()
        {
            clintInfo.id = Request.Query["id"];
            clintInfo.name = Request.Form["name"];
            clintInfo.email = Request.Form["email"];
            clintInfo.phone = Request.Form["phone"];
            clintInfo.address = Request.Form["address"];

            if (clintInfo.name.Length == 0 || clintInfo.email.Length == 0 ||
                clintInfo.phone.Length == 0 || clintInfo.address.Length == 0)
            {
                ErrorMsg = "All the fields are required";
                return;
            }
            try
            {
                string connectionstring = "Data Source=DESKTOP-SABU4KG\\ARVINMSSQLSERVER;Initial Catalog=Arvin;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionstring))
                {
                    con.Open();
                    string sql = "update client set name= @name, email= @email, phone= @phone, address=@address where id = @id";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@name", clintInfo.name);
                        cmd.Parameters.AddWithValue("@email", clintInfo.email);
                        cmd.Parameters.AddWithValue("@phone", clintInfo.phone);
                        cmd.Parameters.AddWithValue("@address", clintInfo.address);
                        cmd.Parameters.AddWithValue("@id", clintInfo.id);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.Message;
                return;
            }
            Response.Redirect("Index");
        }
    }
}
