using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.SqlServer.Server;
using System.Data.SqlClient;

namespace MYStore.Pages.Clients
{
    public class IndexModel : PageModel
    {
        public List<ClintInfo> listClints = new List<ClintInfo>();
        // this method executed when access to the page using httpget, Read the date from the DB
        public void OnGet()
        {
            try
            {
                string connectionstring = "Data Source=DESKTOP-SABU4KG\\ARVINMSSQLSERVER;Initial Catalog=Arvin;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    connection.Open();
                    string sql = "select * from client";
                    using(SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using(SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ClintInfo clintInfo = new ClintInfo();
                                clintInfo.id = "" +reader.GetInt32(0);
                                clintInfo.name = reader.GetString(1);
                                clintInfo.email = reader.GetString(2);
                                clintInfo.phone = reader.GetString(3);
                                clintInfo.address = reader.GetString(4);
                                clintInfo.createddt = reader.GetDateTime(5).ToString();

                                listClints.Add(clintInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }

    public class ClintInfo
    {
        public string id;
        public string name;
        public string email;
        public string phone;
        public string address;
        public string createddt;
    }
}
